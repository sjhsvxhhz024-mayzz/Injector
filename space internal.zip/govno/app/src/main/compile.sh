/data/user/0/com.idragoncheats.studiopro/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build
NDK_PROJECT_PATH=\jni\Main.cpp
NDK_APPLICATION_MK=\jni\Application.mk