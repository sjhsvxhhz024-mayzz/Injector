﻿#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <link.h>
#include <set>
#include <libgen.h>
#include <fcntl.h>
#include <inttypes.h>
#include <sys/mman.h>
#include <dirent.h>
#include <map>
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "oxorany/include.h"
#include "Includes/Utils.h"
#include "Color.h"
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_internal.h"
#include "backends/imgui_impl_opengl3.h"
#include "backends/imgui_impl_android.h"
#define targetLibName oxorany("libunity.so")
#define libil2cpp oxorany("libunity.so")
int glHeight, glWidth;
bool setup;
uintptr_t address;
uintptr_t il2cpp_base;
uintptr_t il2cpp_addr = oxorany(0x0);
uintptr_t shared_base = oxorany(0x0);
int skin_ids [ ] = { oxorany(31004) , oxorany(31001) , oxorany(44902) };

#include "map/Map.hpp"

#include "information.h"

#include "xdl/include/xdl.h"

//#include "chams/opengl.h"

#include "logs.h"

#include "SkinChanger/main.h"

#include "Xhook/xhook.h"

#include "sdk/score_extensions.h"
#include "sdk/player_controller.h"
#include "sdk/photon_player.h"
#include "sdk/transform.h"
#include "sdk/camera.h"
#include "sdk/material.h"
#include "sdk/resources.h"
#include "sdk/renderer.h"
#include "sdk/planted_bomb_controller.h"

#include "render/oh no render is esp.h"
#include "render/bomb hack.h"

#include "il2cpp/il2cpp.h"
#include "hooks.h"
#include "menus.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "logs", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "logs", __VA_ARGS__)

void PatchHex(uintptr_t addr, const uint8_t* bytes, size_t size)
{
	mprotect((void*)(addr & ~0xFFF), 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC);

	for (size_t i = 0; i < size; i++)
		*(uint8_t*)(addr + i) = bytes[i];
}

class InternalPatch
{
public:
	InternalPatch(uintptr_t baseAddr, size_t size, const uint8_t* patchData)
	{
		addr = baseAddr;
		patchSize = size;
		memcpy(patchBytes, patchData, size);
		isPatched = false;
		memset(originalBytes, 0, sizeof(originalBytes));
	}

	void Modify()
	{
		if (!isPatched)
		{
			memcpy(originalBytes, (void*)addr, patchSize);
			PatchHex(addr, patchBytes, patchSize);
			isPatched = true;
		}
	}

	void Restore()
	{
		if (isPatched)
		{
			PatchHex(addr, originalBytes, patchSize);
			isPatched = false;
		}
	}

private:
	uintptr_t addr;
	size_t patchSize;
	uint8_t patchBytes[16]{};
	uint8_t originalBytes[16]{};
	bool isPatched;
};

struct Patches
{
	InternalPatch* win = nullptr;
	InternalPatch* money = nullptr;
	InternalPatch* antigrenade = nullptr;
	InternalPatch* friendlyfire = nullptr;
};

Patches hexPatches;

void SetupImgui() {
    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    io.DisplaySize = ImVec2((float)glWidth, (float)glHeight);

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();
	
	
	ImFontConfig font_cfg;
    _main = io.Fonts->AddFontFromMemoryTTF(Font, sizeof(Font), 35, &font_cfg);
    _main1 = io.Fonts->AddFontFromMemoryTTF(Font, sizeof(Font), 25, &font_cfg);
	verdana = io.Fonts->AddFontFromMemoryTTF(verdana_data, sizeof verdana_data, 13 * 2, NULL, io.Fonts->GetGlyphRangesCyrillic());
	ImGui::GetStyle().WindowRounding = 6;
    ImGui::GetStyle().WindowBorderSize = 0;
    ImGui::GetStyle().ChildRounding = 6;
    // Setup Platform/Renderer backends
    ImGui_ImplOpenGL3_Init(oxorany("#version 300 es"));

    // We load the default font with increased size to improve readability on many devices with "high" DPI.

    font_cfg.SizePixels = 22.0f;
    io.Fonts->AddFontDefault(&font_cfg);
    // Arbitrary scale-up
    ImGui::GetStyle().ScaleAllSizes(2.3f);
}

/*void menus() {
	if ( info_bool :: draw_check )
		ImGui::GetBackgroundDrawList ( ) -> AddCircle ( ImVec2 ( glWidth / 2 ,glHeight / 2 ), info_int :: silent_fov / 0.5 , ImGui::ColorConvertFloat4ToU32 ( ImVec4 ( 255, 255, 255, 1 ) ) );
	
	auto flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar;
	ImGui::SetNextWindowPos(ImVec2(xz, yz));
    ImGui::SetNextWindowSize(ImVec2(x, y));
    ImGui::Begin(oxorany ("Main"), NULL, flags);
    ImGui::SetCursorPos(ImVec2(10,10));
    if (ImGui::InvisibleButton(oxorany ("open"), ImVec2(200, 50))) {
    	menu = !menu;
    }
	if (menu) {
        auto menus = ImGui::GetWindowDrawList();
        auto pos = ImGui::GetWindowPos();
		menus->AddRectFilled(ImVec2(15 + pos.x, 15 + pos.y), ImVec2((ImGui::GetWindowSize().x - 15) + pos.x, 65 + pos.y), ImColor(20, 20, 20),6);
		menus->AddText(ImVec2(50+ pos.x, 20 + pos.y), ImColor(255,255,255,200),  (oxorany("SPACE")));
		ImGui::PushFont(_main1);
		ImGui::SetCursorPos(ImVec2(600, 23));
		if (subtab(oxorany("Aimbot"), taj == 0)) taj = 0;
		ImGui::SameLine(0, 10);
		if (subtab(oxorany("Visuals"), taj == 1)) taj = 1;
		ImGui::SameLine(0, 10);
		if (subtab(oxorany("Misc"), taj == 2)) taj = 2;
		ImGui::SameLine(0, 10);
		if (subtab(oxorany("Skins"), taj == 4)) taj = 4;
		ImGui::SameLine(0, 10);
		if (subtab(oxorany("Info"), taj == 3)) taj = 3;
		ImGui::PopFont();
		switch(taj){
			case 0:
				ImGui::SetCursorPos(ImVec2(15, 80));
				ImGui::PushFont(_main1);
        		ImGui::BeginChild(oxorany ("silent"), ImVec2(300, 550)); {
       			ImGui::SetCursorPos(ImVec2(10, 47));
				ImGui::BeginGroup(); {
					ImGui::Checkbox( oxorany ( " enable " ), & info_bool :: silent_enable );
					ImGui::Checkbox( oxorany ( " visible check " ) , & info_bool :: silent_check );
					ImGui::SliderInt( oxorany ( " fov " ) , & info_int :: silent_fov , 0 , 360 );
					ImGui::Checkbox( oxorany ( " fov :: draw " ) , & info_bool :: draw_check );
					ImGui::Combo( oxorany ( " bone " ) , & info_combo :: ch_bone , info_combo :: bones , IM_ARRAYSIZE ( info_combo :: bones ) );

					ImGui::Checkbox(oxorany(" auto scope "), &info_bool::autoscope);
					ImGui::Checkbox(oxorany(" auto stope "), &info_bool :: autostop);

					ImGui::Checkbox(oxorany(" trigger bot "), &info_bool :: triggerbot);
					if (info_bool :: triggerbot)
					{
						ImGui::SliderFloat( oxorany ( " Trigger Delay " ), &info_float :: trigger_delay, 0.01f, 2.0f);
					}
				}
        		ImGui::EndGroup();  
        		}
       			ImGui::EndChild();
				
	
				ImGui::PopFont();
						
			break;
			
			case 1:
        		ImGui::SetCursorPos(ImVec2(15, 80));
				ImGui::PushFont(_main1);
        		ImGui::BeginChild( oxorany("esp"), ImVec2(300, 550)); {
       			ImGui::SetCursorPos(ImVec2(10, 47));
            	ImGui::BeginGroup(); {
            		ImGui::Checkbox( oxorany ( " Render Players " ) , & info_bool :: render_esp );
					ImGui::Checkbox( oxorany ( " Render Box " ) , & info_bool :: render_box );
					ImGui::Checkbox( oxorany ( " Render Warning " ) , & info_bool :: render_war );
					ImGui::Checkbox( oxorany ( " Render Name " ) , & info_bool :: render_name );
					ImGui::Checkbox( oxorany ( " Render Health " ) , & info_bool :: render_health );
					
        		}
        		ImGui::EndGroup();  
        		}
       			ImGui::EndChild();
				
				ImGui::SetCursorPos(ImVec2(330, 80));
				ImGui::PushFont(_main1);
				ImGui::BeginChild(oxorany ("chams"), ImVec2(300, 550)); {
					ImGui::SetCursorPos(ImVec2(10, 47));
				    ImGui::BeginGroup(); {
						 ImGui::Text(oxorany("CHAMS"));
						 ImGui::Checkbox(oxorany("Chams"), &info_bool::chams);
						 ImGui::Checkbox(oxorany("World Color"), &info_bool::setworldcolor);
						 if (info_bool::setworldcolor)
						 {
							 ImGui::ColorEdit4("World Color", (float*)&info_color::worldColor);
						 }
					}
					ImGui::EndGroup();
				}
				
				ImGui::EndChild();
				
				ImGui::PopFont();
			break;
			
			case 2:
				
				ImGui::SetCursorPos(ImVec2(15, 80));
				ImGui::PushFont(_main1);
				ImGui::BeginChild(oxorany("extensions"), ImVec2(300, 550)); {
					ImGui::SetCursorPos(ImVec2(10, 47));
					ImGui::BeginGroup(); {
						ImGui::Checkbox(oxorany(" add score "), &info_bool::add_score);
						if (ImGui::Checkbox(oxorany(" money hack "), &info_bool::moneyhack))
						{
							if (info_bool::moneyhack && hexPatches.money)
								hexPatches.money->Modify();
							else if (hexPatches.win)
								hexPatches.money->Restore();
						}
						//ImGui::Checkbox(oxorany(" money hack "), &info_bool::moneyhack);
						ImGui::Checkbox(oxorany(" infinity grenade "), &info_bool::infinitygrenade);
						if (ImGui::Checkbox(oxorany(" anti grenade "), &info_bool::antigrenade))
						{
							if (info_bool::antigrenade && hexPatches.antigrenade)
								hexPatches.antigrenade->Modify();
							else if (hexPatches.win)
								hexPatches.antigrenade->Restore();
						}
						ImGui::Checkbox(oxorany(" sky color "), &info_bool::skycolor);
						if (info_bool::skycolor) {
							ImGui::ColorEdit3(oxorany(" sky color "), info_float::skc);
						}

						ImGui::Checkbox(oxorany(" infinity ammo "), &info_bool::ammo);
						ImGui::Checkbox(oxorany(" rapid fire "), &info_bool::rapid_fire);
						ImGui::Checkbox(oxorany(" wall shot "), &info_bool::wall_shot);
						ImGui::Checkbox(oxorany(" air jump "), &info_bool::airjump);

						if (info_bool::test_bool) {
							ImGui::Text(oxorany(" count : %d "), player_list.size());
						}

					} ImGui::EndGroup();
				}
				ImGui::EndChild();

				ImGui::SetCursorPos(ImVec2(330, 80));
				ImGui::PushFont(_main1);
				ImGui::BeginChild(oxorany("exploits"), ImVec2(300, 550)); {
					ImGui::SetCursorPos(ImVec2(10, 47));
					ImGui::BeginGroup(); {

						ImGui::Checkbox(oxorany(" third person "), &info_bool::third_tps);
						if (info_bool::third_tps) {
							ImGui::SliderFloat(oxorany(" tps offset "), &info_float::tps_offset, 0, 5);
						}

						ImGui::Checkbox(oxorany(" Hands Pos "), &info_bool::handspos);
						if (info_bool::handspos) {
							ImGui::SliderFloat(oxorany("Hands Pos X"), &info_float::hands_x, -150.f, 150.f);
							ImGui::SliderFloat(oxorany("Hands Pos Y"), &info_float::hands_y, -150.f, 150.f);
							ImGui::SliderFloat(oxorany("Hands Pos Z"), &info_float::hands_z, -150.f, 150.f);
						}

						ImGui::Checkbox(oxorany(" Anti Aim "), &info_bool::anti_aim);
						if (info_bool::anti_aim) {
							ImGui::Checkbox(oxorany("SpinBot"), &info_bool::aa_spinbot);
							ImGui::SliderFloat(oxorany("Spin Speed"), &info_bool::aa_spin_speed, 1.f, 50.f);

							ImGui::Checkbox(oxorany("Affect Transform"), &info_bool::aa_world);
							ImGui::Checkbox(oxorany("Affect Character"), &info_bool::aa_character);

							ImGui::Checkbox(oxorany("Jitter"), &info_bool::aa_jitter);

							ImGui::SliderFloat(oxorany("Pitch"), &info_bool::aa_pitch, -180.f, 180.f);

							ImGui::Checkbox(oxorany("In Air Only"), &info_bool::aa_in_air_only);
						}

						ImGui::Checkbox(oxorany(" Noclip "), &info_bool::noclip_enable);
						if (info_bool::noclip_enable) {
							ImGui::SliderFloat(oxorany("Noclip Speed"), &info_float::noclip_speed, 0.0f, 5.0f);
						}

						//if (ImGui::Checkbox(oxorany(" friendly fire "), &info_bool::friendlyfire))
						{
							if (info_bool::friendlyfire && hexPatches.friendlyfire)
								hexPatches.friendlyfire->Modify();
							else if (hexPatches.win)
								hexPatches.friendlyfire->Restore();
						}

					}

					ImGui::Checkbox(oxorany(" no recoil "), &info_bool::no_recoil);
					ImGui::Checkbox(oxorany(" Fast Knife "), &info_bool::fastknife);
					//ImGui::Checkbox(oxorany(" move before time "), &info_bool::move_before_time);
					ImGui::Checkbox(oxorany(" One Hit Kill "), &info_bool::onehitkill);

				} ImGui::EndGroup();
				ImGui::EndChild();

				ImGui::SetCursorPos(ImVec2(645, 80));
				ImGui::PushFont(_main1);
				ImGui::BeginChild(oxorany("other"), ImVec2(300, 550)); {
					ImGui::SetCursorPos(ImVec2(10, 47));
					ImGui::BeginGroup(); {
						ImGui::Checkbox(oxorany(" Auto Win "), &info_bool::autowin);
						ImGui::Checkbox(oxorany(" Invisible "), &info_bool::invisible);
						ImGui::Checkbox(oxorany(" Telekill "), &info_bool::telekill);

						ImGui::Checkbox(oxorany(" Fov "), &info_bool::fovhack);
						if (info_bool::fovhack) {
							ImGui::SliderFloat(oxorany(" Fov Value "), &info_bool::fovValue, 45.0f, 180.0f);
						}

						ImGui::Checkbox(oxorany(" bunny hope "), &info_bool::bhop);
						if (info_bool::bhop)
							ImGui::SliderFloat(oxorany(" bhop offset "), &info_float::bhop_offset, 0, 5);

						ImGui::Checkbox(oxorany(" Strafe Helper "), &info_bool::strafehelper);
						ImGui::Checkbox(oxorany(" Air Strafe "), &info_bool::airstrafe);
						//ImGui::Checkbox(oxorany(" Speed Hack "), &info_bool::speedhack);
						if (ImGui::Checkbox(oxorany(" freeze time [only host]"), &info_bool::fastwin))
						{
							if (info_bool::fastwin && hexPatches.win)
								hexPatches.win->Modify();
							else if (hexPatches.win)
								hexPatches.win->Restore();
						}
						ImGui::Checkbox(oxorany(" Big Head "), &info_bool::bighead);
						ImGui::Checkbox(oxorany(" High Jump "), &info_bool::highjump);
						if (info_bool::highjump)
						{
							ImGui::SliderFloat(oxorany(" High Jump "), &info_float::jump_up, 0.0f, 2.0f, "%.2f");
						}
						ImGui::Checkbox(oxorany(" move before time "), &info_bool::move_before_time);

					} ImGui::EndGroup();
				}
				ImGui::EndChild();
				ImGui::PopFont();
				
				
				
				
				
			break;

			case 4:

				ImGui::SetCursorPos(ImVec2(15, 80));
				ImGui::PushFont(_main1);
				ImGui::BeginChild(oxorany("Skins"), ImVec2(300, 550)); {
					ImGui::SetCursorPos(ImVec2(10, 47));
					ImGui::BeginGroup(); {
						ImGui::Combo("Select Skin", &info_combo::selected_skin_id, info_combo::skin_names, info_combo::skin_count);

						if (ImGui::Button("Change Skin")) {
							change(info_combo::skin_ids[info_combo::selected_skin_id]);
						}
					}

					ImGui::EndGroup();
				}
				ImGui::EndChild();

				ImGui::PopFont();
				break;
			
			case 3:
				
				ImGui::SetCursorPos(ImVec2(15, 80));
				ImGui::PushFont(_main1);
        		ImGui::BeginChild( oxorany("information"), ImVec2(300, 550)); {
       			ImGui::SetCursorPos(ImVec2(10, 47));
            	ImGui::BeginGroup(); {
					ImGui::Text( oxorany ( " TGK: @SpaceCheats0 " ) );
					ImGui::Text( oxorany ( " Owner/Coder: Denkiz " ) );
					
					}
					
        		ImGui::EndGroup();  
        		}
       			ImGui::EndChild();
				
				ImGui::PopFont();
			
		}
        if(anals){
        	xx = ImLerp(xx, 550.0f, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
        } else {
           	xx = ImLerp(xx, 50.0f, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
        }
        x = ImLerp(x, 1000.0f, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
        y = ImLerp(y, 650.0f, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
        xz = ImLerp(xz, (ImGui::GetIO().DisplaySize.x - 1000.0f)/2, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
        yz = ImLerp(yz, (ImGui::GetIO().DisplaySize.y - 650.0f)/2, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
		if (snowflakes.empty()) {
        	InitializeSnowflakes();
        }
		for (auto& flake : snowflakes) {
        	flake.position.y += flake.speed;
            if (flake.position.y > ImGui::GetIO().DisplaySize.y)
            	{
                	flake.position.y = 0;
                    flake.position.x = ImGui::GetIO().DisplaySize.x * (rand() / (float)RAND_MAX);
                }
                ImGui::GetBackgroundDrawList()->AddCircleFilled(flake.position, 2, IM_COL32(255, 255, 255, 255), 12);
            }
            
        }
        else {
        	auto menus = ImGui::GetWindowDrawList();
            auto pos = ImGui::GetWindowPos();
			if(x<300){
				ImGui::PushFont(_main);
            	menus->AddText(ImVec2((ImGui::GetWindowSize().x-ImGui::CalcTextSize(oxorany ("SPACE")).x)/2+pos.x,(ImGui::GetWindowSize().y-ImGui::CalcTextSize( ("SPACE")).y)/2+pos.y), ImColor(255, 255, 255),  oxorany("SPACE"));
				ImGui::PopFont();
			}
			
            x = ImLerp(x, 200.0f, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
            y = ImLerp(y, 25.0f, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
            xz = ImLerp(xz, 30.0f, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
            yz = ImLerp(yz, 30.0f, 0.07f * (1.0f - ImGui::GetIO().DeltaTime));
        }
        ImGui::End();
}*/

void menus() {
	if (info_bool::draw_check)
		ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(glWidth / 2, glHeight / 2), info_int::silent_fov / 0.5, ImGui::ColorConvertFloat4ToU32(ImVec4(255, 255, 255, 1)));
	ImGui::SetNextWindowSize(ImVec2(900, 522), ImGuiCond_FirstUseEver);
	ImGui::Begin(oxorany("Planet Mod | t.me/planetcheats"));

	if (ImGui::CollapsingHeader(oxorany("VISUAl"))) {
		ImGui::Checkbox(oxorany(" Render Players "), &info_bool::render_esp);
		ImGui::Checkbox(oxorany(" Render Box "), &info_bool::render_box);
	}

	if (ImGui::CollapsingHeader(oxorany("AIM"))) {
		ImGui::Checkbox(oxorany(" enable "), &info_bool::silent_enable);
		ImGui::Checkbox(oxorany(" visible check "), &info_bool::silent_check);
		ImGui::SliderInt(oxorany(" fov "), &info_int::silent_fov, 0, 360);
		ImGui::Checkbox(oxorany(" fov :: draw "), &info_bool::draw_check);
		ImGui::Combo(oxorany(" bone "), &info_combo::ch_bone, info_combo::bones, IM_ARRAYSIZE(info_combo::bones));
	}

	if (ImGui::CollapsingHeader(oxorany("FUN"))) {
		ImGui::Checkbox(oxorany(" third person "), &info_bool::third_tps);
		if (info_bool::third_tps) {
			ImGui::SliderFloat(oxorany(" tps offset "), &info_float::tps_offset, 0, 5);
		}
		ImGui::Checkbox(oxorany(" bunny hope "), &info_bool::bhop);
		if (info_bool::bhop)
			ImGui::SliderFloat(oxorany(" bhop offset "), &info_float::bhop_offset, 0, 5);
		ImGui::Checkbox(oxorany(" infinity ammo "), &info_bool::ammo);
		ImGui::Checkbox(oxorany(" rapid fire "), &info_bool::rapid_fire);
		ImGui::Checkbox(oxorany(" no recoil "), &info_bool::no_recoil);
		ImGui::Checkbox(oxorany(" auto win "), &info_bool::autowin);
	}
	if (ImGui::CollapsingHeader(oxorany("SKINS"))) {
		ImGui::Combo("Select Skin", &info_combo::selected_skin_id, info_combo::skin_names, info_combo::skin_count);

		if (ImGui::Button("Change Skin")) {
			change(info_combo::skin_ids[info_combo::selected_skin_id]);
		}
	}
}

EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);

    if (!setup) {
        SetupImgui();
        setup = oxorany ( true );
    }

    ImGuiIO &io = ImGui::GetIO();

    // Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
	
    menus ( );
	render ( );
	logs :: render ( ImGui::GetIO ( ).DisplaySize , ImGui::GetBackgroundDrawList( ) , oxorany(16) );
	hit_function ( );
	
    ImGui::EndFrame();
    ImGui::Render();
    glViewport(oxorany(0), oxorany(0), (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());


    return old_eglSwapBuffers(dpy, surface);
}

bool contains(std::string in, std::string target) {
    if(strstr(in.c_str(), target.c_str())) {
        return oxorany(true);
    }
    return oxorany(false);
}

void got_plt_hook()
{
	uintptr_t got = libunity_base + 0x8093130;
	uintptr_t old_addr = *(uintptr_t*)got;
	old_eglSwapBuffers = (decltype(old_eglSwapBuffers))old_addr;
	mprotect((void*)(got & ~0xFFF), 0x1000, PROT_READ | PROT_WRITE);
	*(uintptr_t*)got = (uintptr_t)&hook_eglSwapBuffers;
}

#if defined (__aarch64__)

#define RETURN _("C0 03 5F D6")
#define NOP _("1F 20 03 D5")
#define TRUE _("20 00 80 D2 C0 03 5F D6")
#define FALSE _("00 00 80 D2 C0 03 5F D6")

#else

#define RETURN _("1E FF 2F E1")
#define TRUE _("01 00 A0 E3 1E FF 2F E1")
#define FALSE _("00 00 A0 E3 1E FF 2F E1")

#endif

void *hack_thread(void *) {
	while (!isLibraryLoaded("libunity.so")) {
		sleep(1);
	}

	il2cpp_base = findLibrary("libunity.so");
	libunity_base = findLibrary("libunity.so");

	InitIl2CppAPI();
	got_plt_hook();

	LOGI("il2cpp_base = 0x%lX", il2cpp_base);
	LOGI("libunity_base = 0x%lX", libunity_base);

	get_transform = (void* (*)(void*)) (libunity_base + oxorany(0x48D4208));
	get_position = (vectors::vector3(*)(void*)) (libunity_base + oxorany(0x48E0F60));
	get_camera = (void* (*)()) (libunity_base + oxorany(0x48F9C0C));
	worldtoscreenpoint = (vectors::vector3(*)(void*, vectors::vector3)) (libunity_base + oxorany(0x48F9890));
	get_forward = (vectors::vector3(*)(void*)) (libunity_base + oxorany(0x48E1564));
	set_position = (void (*)(void*, vectors::vector3)) (libunity_base + oxorany(0x48E1000));
	get_BipedMap = (void* (*)(void*))(libunity_base + 0x5B0C240);
	Linecast = (bool (*)(vectors::vector3, vectors::vector3, int)) (libunity_base + 0x5B4B1CC);
	GetHealth = (decltype(GetHealth))(libunity_base + 0x4D95004);
	set_localEulerAngles = decltype(set_localEulerAngles)(libunity_base + 0x48E1364);
	set_eulerAngles = decltype(set_eulerAngles)(libunity_base + 0x48E1258);
	set_localScale = (void (*)(void*, vectors::vector3)) (libunity_base + oxorany(0x48E1790));
	uScreen_get_width = (get_width_t)(libunity_base + 0x4E72AF8);
	uScreen_get_height = (get_height_t)(libunity_base + 0x4E72AF0);

	FindShader = (void* (*)(monoString*)) (libunity_base + 0x490A698); //new
	new_material = (void (*)(void*, void*)) (libunity_base + 0x490ACFC); //new
	set_material = (void (*)(void*, void*)) (libunity_base + 0x490A1A4);//new
	get_material = (void* (*)(void*)) (libunity_base + 0x490A168); //new
	get_materials = (decltype(get_materials))(libunity_base + 0x490A128);
	set_materials = (decltype(set_materials))(libunity_base + 0x490A164);
	set_texture = (decltype(set_texture))(libunity_base + 0x490B438);
	get_texture = (decltype(get_texture))(libunity_base + 0x490B2AC);
	get_type = (decltype(get_type))(libunity_base + 0x47F21DC);
	find_objects = (decltype(find_objects))(libunity_base + 0x48DB0BC);
	has_property = (decltype(has_property))(libunity_base + 0x490B4FC);
	SetIntMaterial = (void (*)(void*, monoString*, int)) (libunity_base + 0x490BF78); //new
	SetColorMaterial = (void (*)(void*, monoString*, ImColor))(libunity_base + 0x490B13C); //new
	get_SkinnedMeshRenderer = (decltype(get_SkinnedMeshRenderer))(libunity_base + 0x49727D0);
	SetFloatMaterial = (decltype(SetFloatMaterial))(libunity_base + 0x490C04C);
	objectswin = decltype(objectswin)(libunity_base + 0x4C84950);

	hexPatches.win = new InternalPatch(libunity_base + 0x4C2FC48, 8, (uint8_t[]) { 0xE0, 0xE1, 0x84, 0xD2, 0xC0, 0x03, 0x5F, 0xD6 });
	hexPatches.money = new InternalPatch(libunity_base + 0x697BAA0, 8, (uint8_t[]) { 0x20, 0x00, 0x80, 0xD2, 0xC0, 0x03, 0x5F, 0xD6 });
	hexPatches.antigrenade = new InternalPatch(libunity_base + 0x691FA0C, 8, (uint8_t[]) { 0x20, 0x00, 0x80, 0xD2, 0xC0, 0x03, 0x5F, 0xD6 });
	hexPatches.friendlyfire = new InternalPatch(libunity_base + 0x53C6F84, 8, (uint8_t[]) { 0x20, 0x00, 0x80, 0xD2, 0xC0, 0x03, 0x5F, 0xD6 });

	void* delegate_input_touch1 = (void*)(libunity_base + 0x858B718);
	while (!*(void**)delegate_input_touch1) {
		sleep(1);
	}
	bool touch = icall_hook(delegate_input_touch1, "UnityEngine.Input::get_touchCount()", hooks::input_get_touchCount, &hooks::old_input_get_touchCount, "libunity");

    /*void* delegate_input_touch = (void*)(il2cpp_base + 0x84DB690);
	while (delegate_input_touch == nullptr) {
		sleep(1);
	}*/

	Il2CppClass* klass12 = GetClassFromA("Assembly-CSharp", "Axlebolt.Standoff.Player", "PlayerController");
	bool hooked11 = method_hook(klass12, "LateUpdate", hooks::player_controller_late_update, &hooks::old_player_controller_late_update, 0);

	Il2CppClass* klass1 = GetClassFromA("Assembly-CSharp", "Axlebolt.Standoff.Player", "PlayerController");
	bool hooked = method_hook(klass1, "Update", hooks::player_controller_update, &hooks::old_player_controller_update, 0);

	void* call_raycast = (void*)(libunity_base + 0x8587E18);
	while (call_raycast == nullptr)
	{
		sleep(1);
	}

	bool ok11 = icall_hook(call_raycast, "UnityEngine.PhysicsScene::Internal_Raycast_Injected(UnityEngine.PhysicsScene&,UnityEngine.Ray&,System.Single,UnityEngine.RaycastHit&,System.Int32,UnityEngine.QueryTriggerInteraction)", hooks::hk_raycast, &hooks::orig_raycast, "libunity");

	//bool ok1 = icall_hook(delegate_input_touch, "UnityEngine.CharacterController::get_isGrounded", (void*)hooks::isGrounded, &hooks::old_isGrounded, "libunity");

	Il2CppClass* klass11 = GetClassFromA("Assembly-CSharp", "Axlebolt.Standoff.Controls", "PlayerControls");
	bool hooked2 = method_hook(klass11, "Update", hooks::updatepl1, &hooks::orig_updatepl1, 0);
	
    pthread_exit(nullptr);
    return nullptr;
}

__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t hacks;
    pthread_create(&hacks, NULL, hack_thread, NULL);
}
