#pragma once

#include "il2cpp/il2cpp.h"

#include "gun_parameters.h"

class c_weapon_parameters : public c_gun_parameters
{
public:
	
};
